package project3;

public class ada {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        System.out.println("Orz");
        
    }

}
